import edu.gwu.lintool.*;

public class DemoTest {

    public static void main (String[] argv)
    {
	LinToolMain.test ();
    }

}
